/* The start Room of Hell 921020 Dancer ... For PKer's */
/*    Edited from Herp's original code ... */
/* Prison.c 910622 Herp --- New, enhanced prison for nerdy wizards. */
 
#include "/players/herp/include/prison.h"
inherit "players/dancer/hell/hell_room";
 
reset(arg) { 
  if (arg) return; 
  short_desc ="Hell";
  long_desc = "\n A Room in Hell.\n\n"
   + "You feel that you are in a very evil place. The room seems to be made\n"
   + "from a natural cavern. There is very little light to be seen, but you\n"
   + "can see just about. There is water dripping down the walls, but as it\n"
   + "nears the ground, it evaporates into steam... This is a very strange \n"
   + "place ...\n";
  LEVEL = 1;
  set_light(1);
  items=({"walls","Hard Rock walls that you would rather not touch",
          "water","It seems like no water that you have seen before"});

  dest_dir=({HOME+"/church","church",
	     HOME+ LEVEL + "/1","south"});

  smell="The overpowering smell of Sulphur";
}
self() { return this_object(); }
 
init() {
    CHECK_CURSE();
}

exit(ob) {
  if(query_verb()!="church" && query_verb() != "south") {
    CHECK_CURSE();
    call_out("no_exit",0,ob);
    return;
  }
}

