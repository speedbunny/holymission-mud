inherit "obj/weapon";

reset(arg) 
{
  ::reset(arg);
    if(!arg) {
    set_name("black scimitar");
    set_alt_name("sword");
    set_alias("scimitar");
    set_short("A black scimitar");
    set_long("This black blade is stained with blood and cold to"+
    " the touch.\n");
    set_class(16);
    set_type(1);
    set_weight(4);
    set_value(200);
    }
}





