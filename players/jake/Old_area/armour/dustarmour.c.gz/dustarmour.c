inherit "/obj/armour";

reset(arg) {
  ::reset(arg);
  if (arg) return 1;
  set_name("dust armour");
  set_type("armour");
  set_ac(2);
  set_short("Dust Armour");
  set_long("This is the armour of he dust monster.  \nIt s dul grey in color.\n");
  set_alias("armour");
  set_value(1000);
  set_weight(4);
  set_info("dust armour (created by Someone using Uranus' Wand)");
  return 1;
}

query_objmaker() { return 1; }
