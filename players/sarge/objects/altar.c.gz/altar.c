#include "setlight.h"
#include <lw.h>

int local_weight;
int chest_is_open;

void init()
  {add_action("open", "open");
  add_action("close", "close");}

int id(string str) 
  {return str=="altar"||str=="panel";}

string short() 
  {return "An altar";}

void long() 
  {writelw(
 "It is a rather large altar of dark mahogany, and engraved with various "+
 "strange runes.  A thick, bloodstained cloth sits atop the altar in "+
 "an ornamental fashion.  Looking closely at the altar also reveals a "+
 "small and well hidden panel on the side.\n");
  if(chest_is_open)
    write("It is open.\n");
  else
    write("It is closed.\n");}

int query_value() 
  {return 200;}

int query_weight() 
  {return 100;}

int get() 
  {return 0;}

int can_put_and_get() 
  {return chest_is_open;}

int add_weight(int w) 
  {if(w+local_weight>10)
    return 0;
  local_weight+=w;
  return 1;}

status close(string str)
  {if(!id(str))
    {notify_fail("Close what?\n");
    return 0;}
  if(!chest_is_open)
    {write("It already is closed.\n");
    return 1;}
  chest_is_open=0;
  write("Ok.\n");
  return 1;}

status open(string str)
  {if(!id(str))
    {notify_fail("Open what?\n");
    return 0;}
  if(chest_is_open)
    {write("It already is open.\n");
    return 1;}
  chest_is_open=1;
  write("Ok.\n");
  return 1;}

void reset(int arg) 
  {if(!present("heart",this_object()))
    {move_object(clone_object("/players/sarge/objects/heart"),this_object());}
  chest_is_open = 0;}

string query_name() 
  {return "An altar";}
