  inherit "obj/weapon";
int i;
reset(arg) {
  ::reset(arg);
if(arg) return;
   set_name("scimitar");
   set_alias("Al-Akbar");
   set_two_handed(1);
   set_read("Al-Akbar");
   set_alt_name("sword");
   set_class(50+(random(6)));
   set_light(5);
   set_hit_func(this_object());
   set_type(30);
   set_weight(15);
   set_value(10000);
   set_short("A Great Scimitar");
   set_long("This is an Arabian scimitar used for beheadings.  It is huge, heavy\n"+
      "and probably impossible to swing.  Runes are written on the blade.\n");
  set_hit_func(this_object());
}

weapon_hit(attacker) {
   int i;
   i=random(6);
if (i==0) {
   write("Al-Akbar reverses your swing and hits again!\n"+
      "You hit.\n");
   say(this_player()->query_name()+"'s scimitar hits with a backswing!\n");
   return 5;
   }
if (i==1) {
   write("Al-Akbar swings a second time!\n");
   say(this_player()->query_name()+" swings a second time!\n");
   return 10;
   }
if (i==2) {
   write("Al-Akbar feels so light you swing with it again!\n");
   say(this_player()->query_name()+" does a quick slash with his scimitar!\n");
   return 20;
   }
if (i==3) {
   write("Al-Akbar swings again screaming: 'KILL!'\n");
   say(this_player()->query_name()+" swings again.  A wierd voice screams 'KILL!'\n");
   return 25;
   }
if (i==4) {
   write("Al-Akbar screams: 'DEATH TO ALL FOES!' as it swings again!\n");
   say(this_player()->query_name()+" swings a second time as a voice screams 'DEATH TO ALL FOES!'\n");
   return 30;
   }
if (i==5) {
   write("Al-Akbar leaps from your grasp and hits your foe 3 times, then returns!\n");
   say(this_player()->query_name()+" loses hold of the scimitar, as the cruel blade attacks on its own!\n");
   return 40;
   }
   }
wield (str) {
   ::wield(str);
   if(id(str));
      write("A strange voice says: 'Hello I am Al-Akbar!, can I be your friend?\n"+
         "You realize it comes from the Scimitar!\n");
      say("A strange voice whispers: 'Hello I am Al-Akbar!, can I be your friend?\n"+
         "as "+this_player()->query_name()+" wields a huge curved sword.\n");
   return 1;
   }
query_hit_msg (dam,name,att,def) {
   if (dam<1) return ({
      "miss "+name+".",
      "misses you. ",
      "misses "+name+" as Mjolnir is too heavy!"});
   else if (dam<2) return({
      "graze "+name+".",
      "grazes you with Mjolnir.",
      "grazes "+name+" with the Mighty Mjolnir!"});
   else if(dam<3) return ({
      "dealt "+name+" a glancing blow.",
      "deals you a glancing blow.",
      "deals "+name+" a glancing blow with Mjolnir!"});
   else if(dam<4) return ({
      "hit "+name+".",
      "hits you.",
      "hits "+name+" with Mjolnir!"});
   else if(dam<5) return ({
      "hits "+name+" pretty hard.",
      "hits you pretty hard.",
      "hits "+name+" pretty hard with Mjolnir!"});
   else if (dam<6) return ({
      "hit "+name+" very hard.",
      "hits you very hard.",
      "hits "+name+" VERY hard with Mjolner!"});
   else if (dam<8) return({
      "hit "+name+" extremely hard.",
      "hits you extremely hard.",
      "hits "+name+" EXTREMELY hard with Mjolnir!"});
   else if (dam<10) return ({
      "smash "+name+".",
      "smashes you.",
      "smashes "+name+" with Mjolnir! "+name+" staggers from the blow!"});
   else if (dam<12) return ({
      "massacre "+name+".",
      "massacres you.",
      "massacres "+name+" with Mjolnir! "+name+" collapses to the ground!"});
   else if (dam<14) return ({
      "massacre "+name+" HARD!",
      "massacres you HARD!",
      "massacres "+name+" HARD with Mjolnir! "+name+" collapses to the ground!"});
   else if (dam<16) return ({
      "massacre "+name+" VERY HARD!",
      "massacres you VERY HARD!",
      "massacres "+name+" VERY HARD with Mjolnir! "+name+" collapses in GREAT pain!"});
   else if (dam<18) return ({
      "smash in "+name+"'s head!",
      "smashes in your head! OUCH!",
      "smashes in "+name+"'s head!!  That had to hurt!"});
   else if (dam<20) return ({
      "hit "+name+". He is shocked by Mjolnir!",
      "shocks you with Mjolnir!!",
      "shocks "+name+" with Mjolnir!!!! You smell Brimstone in the air..."});
   else if (dam<30) return ({
      "hit "+name+".  Electricity surges through your opponent!",
      "shocks you PRETTY HARD!",
      "shocks "+name+" with The Mighty Mjolnir!  Your hair stands on end!"});
   else if (dam<40) return ({
      "hit "+name+" with The Mighty Mjolnir!  Your Opponent glows brightly!",
      "zaps you VERY HARD!!!!!!!! You begin to glow!",
      "zaps "+name+" with so much energy that "+name+" glows brightly!"});
   else if (dam<50) return ({
      "ZAP "+name+"!!!!  You see "+name+"'s skin burn!",
      "zaps you EXTREMELY HARD!!!!!!!!!!! Your skin melts!",
      "zaps "+name+" with enough power to make YOU glow!!!!"});
   else if (dam<80) return ({
      "stun "+name+"!!!!!!!!!!!!!!",
      "hits you and stuns you!!!!!!!!!",
      "stuns "+name+"!!!!!!! "+name+" collapses!"});
   else if (dam<120) return ({
      "electricute "+name+"!!!",
      "electricutes you!!!!!",
      "electricutes "+name+"!!!! "+name+"'s glowing form collapses!"});
   else if (dam<180) return ({
      "flatten "+name+"!",
      "flattens you!!!!!!!!!!",
      "flattens "+name+" into a pancake! OUCH!!!!!!!"});
   else return ({
      "pound "+name+" into a puddle of BLOOD!",
      "pounds you so hard that you collapse into a pool of blood!",
      "pounds "+name+" into a pool of BLOOD!!!!!!!!"});
   }
