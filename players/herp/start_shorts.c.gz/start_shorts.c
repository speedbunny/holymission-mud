object sh;

id(str) { return str=="sh"; }

get() { return 1; }

init() {
     add_action("setsh","setsh");
     add_action("startsh","startsh");
}

startsh() {

    sh=clone_object("/players/herp/short_shadow");
    sh->start_shadow(this_player());
    sh->set_short(this_player()->query_presentation());
    return 1;
}

setsh(str) {
    sh->set_short(str);
    return 1;
}
