#define OWNER	"herp"
#define sh_file	"/d/Wiz/herp/sh/sh_title"

inherit "std/object";

create_object() {
object sh_title;
object u;
    if (!(u=find_player(OWNER))) return;
    call_other(sh_file,"???");
    if (!(sh_title=find_object(sh_file))) {
	tell_object(u,"Failed to create shadow.\n");
	return;
    }
    /* move_object(u);	/* for autoloading */
    tell_object(u,"Starting to shadow.\n");
    sh_title->start_shadow(u);
}

string query_auto_load() {
    return explode(file_name(this_object()),"#")[0]+":0";
}
