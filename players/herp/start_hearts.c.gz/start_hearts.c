object sh;

id(str) { return str=="hsh"; }

short() { return "hsh"; }

get() { return 1; }

init() {
     add_action("hsh","hsh");
}

hsh(str) {
object ob;

    ob=present(str,environment(this_player()));
    if (!ob) {
	notify_fail(str+" not present\n");
	return 0;
    }
    if (!living(ob)) {
	notify_fail(str+" is not a living thing !\n");
	return 0;
    }
    sh=clone_object("/players/herp/heart_shadow");
    sh->start_shadow(ob);
    return 1;
}
