inherit "room/room";

reset(arg) {
    if (arg) return;

    set_light(1);
    short_desc = "The Soul room";
    no_castle_flag = 0;
    long_desc = 
    "You are in a little dusk room. There is a strange feeling in the air.\n"+
    "You should already have a race, if not mail Kelly.\n"+
    "Maybe you can get your exsoul here.\n";
}

init() {
	::init();
	add_action("get_exsoul", "getsoul");
}

get_exsoul() {
	object ob;

	ob = clone_object("tools/exsoul/exsoul");
	transfer(ob, this_player());
	return 1;
}
