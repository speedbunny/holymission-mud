	inherit "room/room";

	reset (arg) {

	set_light(1);
	short_desc = "Near small tarn";
	long_desc =
	  "This is end of the deep ravine. You are standing near small mountain tarn.\n"
	+ "Its water is clear as a crystal and its surface reflect magnificent scenery \n"
	+ "around you. Some places on the steep slopes grow a few dwarf pines, that\n"
	+ "look rather poor, because the climate is very harsh. There path ending.\n"
	+ "If you want go deeper into the mountains, you must go other direction. \n";
	dest_dir = ({"players/titan/quest/rooms/ravine4","southeast"});

	items = ({"tarn","Small mountain tarn",
		"dwarf pines","Usual dwarf pines which vegetate on the slopes",
		"path","Narrow path leading back to the crossroad",
		"mountains","Dark part of mountains"});
}
	init() {
	::init();
	add_action("climb","climb");
	add_action("dive","dive");
	add_action("swim","swim");
}
	climb(str) {
	if(str=="mountain"||str=="slope") {
	write("Don't udnerstand that water is too cold ?\n");
	say(this_player()->query_name()+" tries climb on slope, but fail.\n");
	return 1;
}}
	dive(str) {
	if(str=="into tarn"||str=="tarn"||str=="lake"||str=="into lake") {
	write("Brrrrr !!!! Water is too cold.\n");
	say(this_player()->query_name()+" want dive into tarn, but fail.\n");
	shout(this_player()->query_name()+" shouts: Brrrrrrr !!!!!! \n");
	return 1;
}}
	swim(str) {
	if(str=="tarn"||str=="lake") {
	write("Brrrrr !!!! Water is too cold.\n");
	say(this_player()->query_name()+" tries swim in tarn, but fail.\n");
	shout(this_player()->query_name()+" shouts: Brrrrrrr !!!!!! \n");
	return 1;
}}
