


/* behind_altar */

inherit "/room/room";
#include "defs.h"
object shagath;
int eyes;

void reset(int flag)
{
     ::reset(flag);
     if (flag == 0)
     {
         set_light(0);
         short_desc =
         long_desc = BS(
         "You are behind the altar in Kantele's castle, a passage leads "+
         "west and you can go into the temple proper to the north. "+
         "@@has_eyes@@");
         items =
         ({
            "bottom","The bottom is made of fouly, wooden lathes",
            "ceiling","The ceiling id made if red bricks",
            "walls","The walls are made of red bricks",
            "statue","The statue looks at you",
         });
         dest_dir =
         ({
             PATH+"dirty_temple","north",
         });
      }
      eyes = 1;
}

string has_eyes()
{
    if (eyes)
       return "The Statue of Kali looks at you with burning diamond eyes.";
    return "The Statue of Kali looks at you with empty eyes.";
}

void init()
{
    add_action("do_get","get");     
    add_action("do_get","take");     
    ::init();
}

int do_get(string arg) 
{
   object diamond, scroll; 

   if (!eyes || !arg || (
        arg != "diamond from eyes" &&
        arg != "diamond from eye" && 
        arg != "diamonds from eyes" &&
        arg != "diamonds from eye" &&
        arg != "eyes" && 
        arg != "eye" && 
        arg != "diamonds" && 
        arg != "diamond" )) 
        return 0;

    eyes--;
    write("You pry of a diamond eye.\n");
    say(this_player()->query_name()+" prys off a diamond eye.\n",this_player());

    diamond  = clone_object("obj/treasure");
    diamond->set_id("diamond");
    diamond->set_short("A huge glittering diamond");
    diamond->set_weight(1);
    diamond->set_value(random(2000));
    diamond->set_alias("gem");
    move_object(diamond, this_object());

    if (!shagath) 
    {
	    tell_room(this_object(),
		"The Whole Temple shakes as you feel the Wreath of Kali !\n"+
		"Shagath the avatar of Kali arrives in a puff of smoke !\n");

     	shagath  = clone_object("obj/monster");
	   call_other(shagath, "set_name", "shagath");
	   call_other(shagath, "set_alias", "avatar");
	   call_other(shagath, "set_level",60);
	   call_other(shagath, "set_al", -3000);
	   call_other(shagath, "set_short",
		   "Shagath the avatar of Kali is here");
	   call_other(shagath, "set_wc",80);
	   call_other(shagath, "set_ac",30);
	   call_other(shagath, "set_aggressive", 1);
	   call_other(shagath, "set_chance",90);
	   call_other(shagath, "set_spell_mess1",
		   "Shagath throws Hellfire.");
	   call_other(shagath, "set_spell_mess2",
		   "You are hit by the Hellfire");
	   call_other(shagath, "set_spell_dam",150+random(200));
      call_other(shagath,"set_number_of_arms",3);
	   move_object(shagath, this_object());
	   call_other(shagath, "attack_object", this_player());
      scroll = clone_object("/players/whisky/kantele/obj/disp_scroll");
      move_object(scroll,shagath);
    }
    return 1;
}
