/* 270793: Galadriel: Fixed weight bug. (and a load of typos)  */
/* 270793: Galadriel: It now shouts the correct number of stars */
#define T this_player()
inherit "/obj/treasure";

reset(arg) {
if (arg) return;

    set_id("star");
    set_alias("golden star");
    set_short("The golden star");
    set_long("If you now have the rest four stars then <shoot> them now!!.\n");
   set_value(4000);
}

init() {
  ::init();
    add_action("shoot","shoot");
  }

shoot(str) {
object burst,red,blue,green,silver;
    if(str!="stars") return;
if(present("blue star",T)&&present("green star",T)&&present("red star",T)&&present("silver star",T))
 {
write("As you shoot the blue star a blue ball of fire explodes in the sky.\n\n");
write("As you shoot the red star a blue ball of fire explodes in the sky.\n\n");
write("As you shoot the green star a blue ball of fire explodes in the sky.\n\n");
write("As you shoot the silver star a blue ball of fire explodes in the sky.\n\n");

write("Suddenly as you shoot the golden star a gigantic golden\n"+
"ball of fire explodes in the sky and melts all the five coloured\n"+
"stars to the mightiest weapon gods ever seen.\n");
say(T->query_name()+" makes a magical gesture and suddenly a\n"+
"ball of fire explodes in the sky and melts five coloured fireballs to\n"+
"the mightiest weapon gods ever seen.\n");

burst = clone_object("players/whisky/seaworld/obj/starburst2");
/* Galadriel: Now it adds correct weight to player for burst */
red = present("red star",T);
blue = present("blue star",T);
green = present("green star",T);
silver = present("silver star",T);
destruct(red);
destruct(blue);
destruct(green);
destruct(silver);
transfer(burst,T);
shout(this_player()->query_name()+" sends a mighty fireball to heaven.\n"+
      "as "+this_player()->query_pronoun()+" shoots the mighty starburst.\n");
destruct(this_object());
return 1; }
}
