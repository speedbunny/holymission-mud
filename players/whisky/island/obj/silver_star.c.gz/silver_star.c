/* 270793: Galadriel: fixed weight bug. */
#define T this_player()
inherit "/obj/treasure";

reset(arg) {
if (arg) return;

    set_id("star");
    set_alias("silver star");
    set_short("The silver star");
    set_long("The last part of the little Starburst or the part (4)\n"+
    "of the mighty one. Look after the last part or just <create> it now!!\n");
    set_value(800);
}

init() {
  ::init();
   add_action("create","create");
  }

create(str) {
object burst,red,blue,green;
    if(str!="starburst") return;
 if (present("blue star",T) && present("green star",T) && present("red star",T))
 {
write("The red star shoots a lousy little spark to heaven.\n");
write("The blue star shoots a lousy little spark to heaven.\n");
write("The green star shoots a lousy little spark to heaven.\n");
write("But suddenly the silver star explodes in the air and melts\n");
write("all four stars and the little Starburst appears in your hands.\n");

say(T->query_name()+" makes a magical geasture and suddenly a\n"+
"ball of fire explodes in heaven and melts four coloured sparks to\n"+
"the little Starburst.\n");

burst =clone_object("players/whisky/seaworld/obj/starburst");
/* Galadriel: now it adds weight for the little starburst correct */
red = present("red star",T);
blue = present("blue star",T);
green = present("green star",T);
destruct(red);
destruct(blue);
destruct(green);
transfer(burst,T);
destruct(this_object());
return 1; }
}
