
/* morningstar */

inherit "/obj/weapon";

void reset(int arg)
{
     ::reset(arg);
     if (!arg)
     {
         set_name("steel morningstar");
         set_alias("morningstar");
         set_short(query_name());
         set_long("A spiked ball on an iron chain.\n");
         set_weight(2);
         set_class(20);
         set_value(5000);
         set_type(2);
     }
}

 
