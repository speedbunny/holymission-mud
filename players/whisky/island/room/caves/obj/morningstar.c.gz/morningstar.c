
/* morningstar */

inherit "/obj/weapon";

void reset(int arg)
{
     ::reset(arg);
     if (!arg)
     {
         set_name("heavy morningstar");
         set_alias("morningstar");
         set_short(query_name());
         set_long("A spiked ball on an iron chain.\n");
         set_weight(3);
         set_class(18);
         set_value(900);
         set_type(2);
     }
}

 
