inherit "players/ted/items/wand";

reset(arg) {
  if(arg) return;
  name = "wand of shooting stars";
  alias = "silver wand";
  short_desc = "A Silver Wand";
  long_desc =
  "This wand appears to be made out of some silver metal.\n"+
  "It feels magical, maybe you should get it identified?\n";
  do_cmd = "shoot";
  spell_type = "burst of shooting stars";
  spell_mess1 = "A burst of shooting stars shoots forth!";
  spell_mess2 = "You pelt your oponent with a blast of shooting stars!";
  charges = random(8)+2;
  value = charges*90;
  weight = 1;
  spell_dam = 15;
}
