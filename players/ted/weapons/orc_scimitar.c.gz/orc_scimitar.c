inherit "obj/weapon";

reset(arg) {
  ::reset(arg);
  if(arg) return;
  set_name("scimitar");
  set_short("A Scimitar");
  set_class(10);
  set_weight(2);
  set_value(75);
}
