inherit "obj/weapon";

reset(arg) {
  ::reset(arg);
  if(arg) return;
 set_name("Fire Giant Bastardsword");
 set_alias("bastardsword");
 set_short("A Fire Giant Bastardsword");
 set_long("This is a finely made sword, large, strong and sharp.\n");
 set_class(18);
 set_weight(4);
 set_value(2500);
}
