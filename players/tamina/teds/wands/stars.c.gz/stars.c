inherit "players/tamina/teds/inherits/wand";

void reset(int arg) 
{
  ::reset(arg);
  if(arg) return 0;

  name = "wand of shooting stars";
  alias = "platinum wand";
  short_desc = "A Platinum Wand";
  long_desc =
  "This wand appears to be made out of some expensive platinum.\n"+
  "It feels magical, maybe you should get it identified?\n";

  do_cmd = "shoot";
  spell_type = "burst of shooting stars";
  spell_mess1 = "A burst of shooting stars shoots forth!";
  spell_mess2 = "You pelt your oponent with a blast of shooting stars!";
  charges = random(8) + 2;
  value = charges * 90;
  weight = 1;
  spell_dam = 15 + random(8);
  kind = 5;
  elem = ({5, 12});
}
