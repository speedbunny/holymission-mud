inherit "/obj/weapon";


reset(arg) {
if (arg) return;

    set_id("burst");
    set_alias("starburst");
    set_short("The little Starburst");
    set_long("The little sister of the mighty Starburst.\n");
    set_type(2);
    set_light(1);
    set_class(2);
    set_hit_func(this_object());
    set_weight(1);
    set_value(2000);
}

   weapon_hit(attacker) {
      write("****************************************************\n"+
            "As you shoot the red star it burns "+attacker->query_name()+" badly.\n"+
          "The green star blinds "+attacker->query_name()+" for a moment.\n"
         + "And the blue star hits "+attacker->query_name()+" so hard it cries..\n"
           + "*****************************************************\n");

      say(this_player()->query_name()+" throws the little Starburst against "+attacker->query_name()+".\n");
  return random(34); }
