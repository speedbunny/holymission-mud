inherit "/obj/weapon";
#define LEN 70

string verb_dam(int d,object a);
void writec(string str);
#define ATTNAME \
  (attacker->query_real_name() ? capitalize(attacker->query_real_name()) :\
   "your oponent")

int mpower;
int llevel;
int *dam;
int heart_beat;
string *color;

void reset(int flag) 
{
   mpower = 7;

   if (flag == 0) 
   {

      set_alias("stars");
      set_name("sword of seven stars");
      set_alt_name("sword");
      set_short("Sword of seven stars");
      set_long(
      "The famous sword of seven stars forged by Quan Xi, mystic blacksmith\n"+
      "of the dragon gods. It's a short sword with seven different gems\n"+
      "that seems to pulses with power. These gems rumored to be eyes of\n"+
      "ancient dragons of the seven elements: wind, water, fire, wood,\n"+
      "death, life, and light.\n");
      set_type(2);
      set_hit_func(this_object());
      set_weight(1);
      set_value(15000);
      llevel=0;
     dam=allocate(7);
      color=({ "red", "green", "blue", "silver", "golden", "white", "black" });
   }
}



int weapon_hit(object attacker) 
{
   int i,sum;
  
  for (i=0;i < 7; i++) dam[i] = random(random(20));
 /* random of 18 = 8,5   random of 8,5 * 5 = 17,5 || 20 = 18,75 */
   for(i=0;i<7;i++) {
      writec(" the "+color[i]+" star shoots at "+ATTNAME+" and "+
            verb_dam(dam[i],attacker)+" ");
      sum+=dam[i];
   }
   say(this_player()->query_name()+" points the Sword of Seven Stars at "+
      attacker->query_name()+" !!!!\n");
   
   return sum;
}

string verb_dam(int d,object a) 
{
   switch(d) 
   {
      case 0: return "misses.";
      case 1: return "scratches "+a->query_objective()+".";
      case 2: return "gazes "+a->query_objective()+".";
      case 3: return "edges "+a->query_possessive()+" body.";
      case 4: return "cuts in "+a->query_possessive()+" flesh.";
      case 5: return "hits "+a->query_objective()+" badly.";
      case 6: return "smashes in "+a->query_possessive()+" face!";
      case 7: return "bursts in "+a->query_possessive()+" rips!";
      default: return "shines.";
   }
}


     
int wield(string arg)
{
    if (id(arg) && (!query_wielded()) )
    {
      if (this_player()->query_hands_free())
      {
          write("A soft light blue aura envelopes your body.\n");
          say(this_player()->query_name()+" emits a light blue glow.\n");
          }
   }
     return ::wield(arg);
   }

void my_heart_beat()
{
   heart_beat = 0;
}

void writec(string str)
{
int l,i;
string out;
out="";
l=strlen(str);
for(i=0;i<(LEN-l)/2;i++) out+="*";
out+=str;
for(i=strlen(out);i<LEN;i++) out+="*";
write(out+"\n");
}
