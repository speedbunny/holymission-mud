inherit "room/room";
#include <lw.h>

#define PATH "players/kawai/areas/games/"
#define RETURN_POINT "room/church"

void reset(int arg) 
  {set_light(1);
  short_desc="A White Room";
  long_desc="You stand in the middle of a hazy white room, with no noticable features "+
  "except for a shimmering portal a few feet in front of you.  Next to the portal is "+
  "what appears to be a small plaque, though not quite tangible.\n";
  dest_dir=({PATH+"mines","portal"});
  items=({"room","Just look around",
  "portal","A shimmering portal, probably one that will take you to an unusual place",
  "plaque","Try reading it"});
   ::reset(arg);}


void init()
  {::init();
  add_action("beg","beg");
  add_action("read","read");
  add_action("check","portal");}


status beg()
  {writelw(
  "The Grand Wizard appears before you and says:  You are a coward, just "+
  "as I suspected.  Nevertheless, you may return to your pathetic domain.\n\n");
  this_player()->move_player("in a puff of smoke#"+RETURN_POINT);
  return 1;}


status read(str) 
  {if(!str)
    {notify_fail("Read what?\n");
    return 0;}
  if(str=="plaque")
    {writelw("As you reach out to touch the plaque, a Grand Wizard appears before you "+
    "and says:  Greetings, adventurer!  As you can probably tell, despite your obvious "+
    "lack of intelligence, I am one of this land's Grand Wizards, and my specialty, as "+
    "we all have one, is that of games.  There is no doubt among all those who inhabit "+
    "this world that I am the wisest and most clever of all creatures, but for those few "+
    "fools who dare challenge that, I have devised a simple test to prove my point.  "+
    "If you are up to the challenge, you may pass through this portal and begin your "+
    "quest, but I must warn you:  If you fail at any point, the consequences shall be "+
    "severe!  But, if you are a coward, as I suspected, you may 'beg' for forgiveness, "+
    "as you have disturbed me while napping.  I may find it in my heart to forgive you "+
    "and return you to a familiar place.  Now, if you would quickly make up your mind "+
    "so I can get back to sleep...\n");
    return 1;}
  else
    {notify_fail("You can't read that.\n");
    return 0;}}

status check()
  {object st;
  if(!st=present("gstub",this_player()))
    {return 0;}
  switch(st->query_last())
    {case 0: return;
             break;
    case 1: this_player()->move_player("through the portal",PATH+"coins");
            return 1;
            break;
    case 2: this_player()->move_player("through the portal",PATH+"knight");
            return 1;
            break;
    default: return 0; 
             break;}
  return 0;}


  
