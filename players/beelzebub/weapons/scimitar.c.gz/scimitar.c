
inherit "/obj/weapon";

reset(arg) {
  ::reset(arg);
  if (arg) return;

  set_name("Scimitar");
  set_alias("scimitar");
  set_class(10);
  set_short("A scimitar");
  set_long("This is the weapon of the Netherworld's Swordsmen. \n" +
           "It is a very light and very sharp weapon. \n");
  set_value(2500);
  set_weight(2);
  return 1;
}

