inherit "/obj/weapon";

#define TPA 	this_player()->query_alignment()

reset(arg) {
  ::reset(arg);
  if (arg) return 1;
  set_name("vampire stare");
  set_alias("stare");
  set_read("You stare at your opponent giving him a power mental blast !!\n");
  set_class(15);
  set_short("Vampire Stare");
  set_long("This is a powerful undead weapon..use with caution...\n");
  set_value(12000);
  set_weight(2);
  set_hit_func(this_object());
  return 1;
}

/* The weapon class depends on the alignment of the player *grin* , 
   more evil better wc */
weapon_hit(obj) {
int wc;
  if(TPA>0) return 10;
  if(TPA>-100) return (TPA/20);
  if(TPA>-1000) return (TPA/100 +17);
  if(TPA>-2000) return ((TPA/400)+25);
  if(TPA<=-2000) return 35;
}
