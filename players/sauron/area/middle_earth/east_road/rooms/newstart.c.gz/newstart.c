inherit "/room/room";

#include "/players/sauron/defs.h"

int touch(string arg) {
  if(arg == "ring") {
    write("As you reach out to touch the ring, a leafy hand grabs you and " +
          "pulls you into another world.\n");
    TP->MOVEP("is dragged into another world#" + MERRMS + "newtree2");
    say("A leafy hand reaches out from the tree and grabs " + TP->RNAME +
        ", pulling " + HIM + "into another world");
    return 1;
  }
  else {
    write("Touch what?\n");
    return 1;
  }
}

reset(arg) {
  ::reset(arg);
  if(!arg) {
    set_light(1);
    short_desc="A road";
    long_desc="You find yourself standing at the bend of a road, which leads " +
              "off east and northwest. The land is well inhabited, with farms " +
              "dotted around the countryside. In the distance to the west you " +
              "can see a magnificent white tower. As you turn and look east " +
              "you see a forboding darkness looming over jagged mountains. " +
              "Behind you you can see a single tree with a ring carved into " +
              "the trunk.\n";
    dest_dir=({
      "/players/colossus/mearth/shire/entrance","northwest",
      MERRMS + "road1","east",
    });
    items=({
      "road","The road is a good, well kept road, just right for walking " +
             "or riding along",
      "farms","You can just make out farms dotted around the countryside",
      "countryside","A wide respectable country inhabited by decent folk",
      "tower","A magnificent white tower",
      "white tower","A magnificent white tower",
      "magnificent white tower","A magnificent white tower",
      "darkness","A dark cloud hangs over the land to the east, as if some " +
                 "great evil exists there",
      "foreboding darkness","A dark cloud hangs over the land to the east, " +
                            "as if some great evil exists there",
      "cloud","A dark cloud hanging over the land to the east",
      "dark cloud","A dark cloud hanging over the land to the east",
      "mountains","Huge jagged mountains loom on the horizon",
      "jagged mountains","Huge jagged mountains loom on the horizon",
      "tree","A single solitary tree with a ring carved into the trunk",
      "single tree","A single solitary tree with a ring carved into the trunk",
      "solitary tree","A single solitary tree with a ring carved into the " +
                      "trunk",
      "single solitary tree","A single solitary tree with a ring carved into " +
                             "the trunk",
      "trunk","The trunk of a tree with a ring carved into it. Maybe if you " +
              "touched the ring you could escape from this world",
    });
  }
}

init() {
  ::init();
  add_action("touch", "touch");
}